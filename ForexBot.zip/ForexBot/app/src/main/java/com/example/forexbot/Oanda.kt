package com.example.forexbot

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Candle(val h: Double, val l: Double, val c: Double)

class Oanda(private val token: String, private val account: String, demo: Boolean) {
    private val base = if (demo) "https://api-fxpractice.oanda.com" else "https://api-fxtrade.oanda.com"

    private fun call(method: String, path: String, body: String? = null): JSONObject {
        val con = URL(base + path).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.setRequestProperty("Authorization", "Bearer $token")
        con.setRequestProperty("Content-Type", "application/json")
        con.connectTimeout = 15000; con.readTimeout = 15000
        if (body != null) { con.doOutput = true; con.outputStream.use { it.write(body.toByteArray()) } }
        val ok = con.responseCode in 200..299
        val text = (if (ok) con.inputStream else con.errorStream).bufferedReader().readText()
        if (!ok) error("HTTP ${con.responseCode}: ${text.take(200)}")
        return JSONObject(text)
    }

    fun balance() = call("GET", "/v3/accounts/$account/summary")
        .getJSONObject("account").getString("balance").toDouble()

    fun openInstruments(): Set<String> {
        val a = call("GET", "/v3/accounts/$account/openPositions").getJSONArray("positions")
        return (0 until a.length()).map { a.getJSONObject(it).getString("instrument") }.toSet()
    }

    fun candles(pair: String, tf: String): List<Candle> {
        val a = call("GET", "/v3/instruments/$pair/candles?granularity=$tf&count=200&price=M").getJSONArray("candles")
        return (0 until a.length()).map { a.getJSONObject(it) }.filter { it.getBoolean("complete") }.map {
            val m = it.getJSONObject("mid")
            Candle(m.getString("h").toDouble(), m.getString("l").toDouble(), m.getString("c").toDouble())
        }
    }

    fun market(pair: String, units: Int, sl: String, tp: String) {
        val body = """{"order":{"type":"MARKET","instrument":"$pair","units":"$units","timeInForce":"FOK",
            "stopLossOnFill":{"price":"$sl"},"takeProfitOnFill":{"price":"$tp"}}}"""
        call("POST", "/v3/accounts/$account/orders", body)
    }
}
