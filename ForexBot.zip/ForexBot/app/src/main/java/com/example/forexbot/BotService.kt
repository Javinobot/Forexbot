package com.example.forexbot

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class BotService : Service() {
    companion object {
        val logs = MutableStateFlow<List<String>>(emptyList())
        val running = MutableStateFlow(false)
        fun log(s: String) {
            val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            logs.value = (listOf("$t  $s") + logs.value).take(100)
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "bot").setContentTitle("Binance Bot actif")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (job == null) { running.value = true; job = scope.launch { loop() } }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel(); job = null; running.value = false; log("Bot arrêté"); super.onDestroy()
    }

    private suspend fun loop() {
        val p = getSharedPreferences("cfg", 0)
        val testnet = p.getBoolean("testnet", true)
        val api = Binance(p.getString("key", "")!!, p.getString("secret", "")!!, testnet)
        val syms = p.getString("symbols", "BTCUSDT,ETHUSDT,BNBUSDT")!!.split(",").map { it.trim().uppercase() }
        val riskPct = p.getFloat("risk", 1f) / 100.0
        val store = getSharedPreferences("pos", 0)
        val pos = JSONObject(store.getString("p", "{}")!!)
        val cache = mutableMapOf<String, Filters>()
        fun save() = store.edit().putString("p", pos.toString()).apply()
        log("Démarré (${if (testnet) "TESTNET" else "RÉEL"}) $syms 15m")

        while (currentCoroutineContext().isActive) {
            try {
                for (sym in syms) {
                    val c = api.candles(sym, "15m"); if (c.size < 60) continue
                    val price = api.price(sym)
                    val f = cache.getOrPut(sym) { api.filters(sym) }

                    if (pos.has(sym)) {
                        val o = pos.getJSONObject(sym)
                        val reason = when {
                            price <= o.getDouble("sl") -> "SL"
                            price >= o.getDouble("tp") -> "TP"
                            Strategy.signal(c) == Side.SELL -> "croisement"
                            else -> null
                        }
                        if (reason != null) {
                            val qty = f.floor(minOf(o.getDouble("qty"), api.balances()[f.base] ?: 0.0))
                            if (qty.toDouble() >= f.minQty) { api.market(sym, "SELL", qty); log("VENTE $sym $qty ~${"%.4f".format(price)} ($reason)") }
                            pos.remove(sym); save()
                        }
                        continue
                    }
                    if (pos.length() >= 2 || Strategy.signal(c) != Side.BUY) continue
                    val usdt = api.balances()["USDT"] ?: 0.0
                    val a = Strategy.atr(c); val slD = a * 1.5
                    val qty = f.floor(minOf(usdt * riskPct / slD, usdt * 0.30 / price))
                    if (qty.toDouble() < f.minQty || qty.toDouble() * price < f.minNotional) { log("$sym : quantité trop petite"); continue }
                    val r = api.market(sym, "BUY", qty)
                    val got = r.getString("executedQty").toDouble()
                    val entry = if (got > 0) r.getString("cummulativeQuoteQty").toDouble() / got else price
                    pos.put(sym, JSONObject().put("qty", got).put("sl", entry - slD).put("tp", entry + a * 3.0)); save()
                    log("ACHAT $sym $got @ ${"%.4f".format(entry)} | SL ${"%.4f".format(entry - slD)} TP ${"%.4f".format(entry + a * 3.0)}")
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { log("Erreur : ${e.message}") }
            delay(30_000)
        }
    }
}
