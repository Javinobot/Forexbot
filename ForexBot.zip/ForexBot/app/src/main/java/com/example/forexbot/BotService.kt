package com.example.forexbot

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.*

class BotService : Service() {
    companion object {
        val logs = MutableStateFlow<List<String>>(emptyList())
        val running = MutableStateFlow(false)
        fun log(s: String) {
            val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            logs.value = (listOf("$t  $s") + logs.value).take(100)
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "bot")
            .setContentTitle("Forex Bot actif").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (job == null) { running.value = true; job = scope.launch { loop() } }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel(); job = null; running.value = false; log("Bot arrêté"); super.onDestroy()
    }

    private suspend fun loop() {
        val p = getSharedPreferences("cfg", 0)
        val api = Oanda(p.getString("token", "")!!, p.getString("account", "")!!, p.getBoolean("demo", true))
        val pairs = p.getString("pairs", "EUR_USD,GBP_USD,USD_JPY")!!.split(",").map { it.trim() }
        val riskPct = p.getFloat("risk", 1f) / 100.0
        val tf = "M15"; val maxOpen = 2
        log("Démarré (${if (p.getBoolean("demo", true)) "DÉMO" else "RÉEL"}) $pairs $tf")
        val lastClose = mutableMapOf<String, Double>()
        while (currentCoroutineContext().isActive) {
            try {
                val open = api.openInstruments().toMutableSet()
                for (pair in pairs) {
                    if (pair in open || open.size >= maxOpen) continue
                    val c = api.candles(pair, tf)
                    if (c.isEmpty() || lastClose[pair] == c.last().c) continue
                    lastClose[pair] = c.last().c
                    val side = Strategy.signal(c) ?: continue
                    val a = Strategy.atr(c); val price = c.last().c
                    val dp = if ("JPY" in pair) 3 else 5
                    val slD = a * 1.5; val tpD = a * 3.0
                    val units = ((api.balance() * riskPct) / slD).toInt()
                    if (units < 1) continue
                    val (u, sl, tp) = if (side == Side.BUY) Triple(units, price - slD, price + tpD)
                    else Triple(-units, price + slD, price - tpD)
                    api.market(pair, u, "%.${dp}f".format(Locale.US, sl), "%.${dp}f".format(Locale.US, tp))
                    open += pair
                    log("$side $pair $u u | SL ${"%.${dp}f".format(sl)} TP ${"%.${dp}f".format(tp)}")
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { log("Erreur : ${e.message}") }
            delay(60_000)
        }
    }
}
