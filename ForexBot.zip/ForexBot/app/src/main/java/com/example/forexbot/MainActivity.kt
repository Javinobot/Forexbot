package com.example.forexbot

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        setContent { MaterialTheme { Screen() } }
    }
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val p = remember { ctx.getSharedPreferences("cfg", 0) }
    var token by remember { mutableStateOf(p.getString("token", "")!!) }
    var account by remember { mutableStateOf(p.getString("account", "")!!) }
    var pairs by remember { mutableStateOf(p.getString("pairs", "EUR_USD,GBP_USD,USD_JPY")!!) }
    var risk by remember { mutableStateOf(p.getFloat("risk", 1f).toString()) }
    var demo by remember { mutableStateOf(p.getBoolean("demo", true)) }
    val running by BotService.running.collectAsState()
    val logs by BotService.logs.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Forex Bot", fontSize = 24.sp)
        OutlinedTextField(token, { token = it }, label = { Text("Token API OANDA") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !running)
        OutlinedTextField(account, { account = it }, label = { Text("ID du compte") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !running)
        OutlinedTextField(pairs, { pairs = it }, label = { Text("Paires (séparées par des virgules)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !running)
        OutlinedTextField(risk, { risk = it }, label = { Text("Risque par trade (%)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !running)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(demo, { demo = it }, enabled = !running)
            Spacer(Modifier.width(8.dp))
            Text(if (demo) "Compte DÉMO" else "Compte RÉEL ⚠️")
        }
        Button(
            onClick = {
                val i = Intent(ctx, BotService::class.java)
                if (running) ctx.stopService(i) else {
                    p.edit().putString("token", token.trim()).putString("account", account.trim())
                        .putString("pairs", pairs).putFloat("risk", risk.toFloatOrNull() ?: 1f)
                        .putBoolean("demo", demo).apply()
                    ContextCompat.startForegroundService(ctx, i)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (running) "Arrêter le bot" else "Démarrer le bot") }
        LazyColumn { items(logs) { Text(it, fontSize = 12.sp) } }
    }
}
