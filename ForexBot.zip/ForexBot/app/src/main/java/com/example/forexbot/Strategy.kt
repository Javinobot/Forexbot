package com.example.forexbot

import kotlin.math.abs
import kotlin.math.max

enum class Side { BUY, SELL }

object Strategy {
    private fun ema(v: List<Double>, n: Int): List<Double> {
        val k = 2.0 / (n + 1); var e = v[0]
        return v.map { x -> e = x * k + e * (1 - k); e }
    }

    private fun rsi(v: List<Double>, n: Int = 14): Double {
        var g = 0.0; var l = 0.0
        for (i in 1..n) { val d = v[i] - v[i - 1]; g += max(d, 0.0); l += max(-d, 0.0) }
        var ag = g / n; var al = l / n
        for (i in n + 1 until v.size) {
            val d = v[i] - v[i - 1]
            ag = (ag * (n - 1) + max(d, 0.0)) / n
            al = (al * (n - 1) + max(-d, 0.0)) / n
        }
        return if (al == 0.0) 100.0 else 100 - 100 / (1 + ag / al)
    }

    fun atr(c: List<Candle>, n: Int = 14): Double {
        val tr = (1 until c.size).map { max(c[it].h - c[it].l, max(abs(c[it].h - c[it - 1].c), abs(c[it].l - c[it - 1].c))) }
        var a = tr.take(n).average()
        tr.drop(n).forEach { a = (a * (n - 1) + it) / n }
        return a
    }

    /** Croisement EMA20/EMA50 sur la dernière bougie clôturée + filtre RSI. */
    fun signal(c: List<Candle>): Side? {
        if (c.size < 60) return null
        val cl = c.map { it.c }
        val e20 = ema(cl, 20); val e50 = ema(cl, 50); val r = rsi(cl)
        val n = cl.size
        return when {
            e20[n - 2] <= e50[n - 2] && e20[n - 1] > e50[n - 1] && r < 70 -> Side.BUY
            e20[n - 2] >= e50[n - 2] && e20[n - 1] < e50[n - 1] -> Side.SELL
            else -> null
        }
    }
}
