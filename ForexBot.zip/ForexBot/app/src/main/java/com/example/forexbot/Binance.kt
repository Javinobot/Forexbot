package com.example.forexbot

import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class Candle(val h: Double, val l: Double, val c: Double)
data class Filters(val step: BigDecimal, val minQty: Double, val minNotional: Double, val base: String) {
    fun floor(d: Double): BigDecimal = BigDecimal(d).divide(step, 0, RoundingMode.DOWN).multiply(step)
}

class Binance(private val key: String, private val secret: String, testnet: Boolean) {
    private val base = if (testnet) "https://testnet.binance.vision" else "https://api.binance.com"

    private fun call(method: String, path: String, params: Map<String, String> = emptyMap(), signed: Boolean = false): String {
        var q = params.entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
        if (signed) {
            q += (if (q.isEmpty()) "" else "&") + "timestamp=${System.currentTimeMillis()}&recvWindow=10000"
            val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(secret.toByteArray(), "HmacSHA256")) }
            q += "&signature=" + mac.doFinal(q.toByteArray()).joinToString("") { "%02x".format(it) }
        }
        val con = URL(base + path + if (q.isNotEmpty()) "?$q" else "").openConnection() as HttpURLConnection
        con.requestMethod = method
        con.setRequestProperty("X-MBX-APIKEY", key)
        con.connectTimeout = 15000; con.readTimeout = 15000
        if (method == "POST") { con.doOutput = true; con.outputStream.use { it.write(ByteArray(0)) } }
        val ok = con.responseCode in 200..299
        val text = (if (ok) con.inputStream else con.errorStream).bufferedReader().readText()
        if (!ok) error("HTTP ${con.responseCode}: ${text.take(200)}")
        return text
    }

    fun candles(sym: String, tf: String): List<Candle> {
        val a = JSONArray(call("GET", "/api/v3/klines", mapOf("symbol" to sym, "interval" to tf, "limit" to "200")))
        return (0 until a.length() - 1).map { a.getJSONArray(it) }  // dernière bougie = en cours, ignorée
            .map { Candle(it.getString(2).toDouble(), it.getString(3).toDouble(), it.getString(4).toDouble()) }
    }

    fun price(sym: String) = JSONObject(call("GET", "/api/v3/ticker/price", mapOf("symbol" to sym))).getString("price").toDouble()

    fun balances(): Map<String, Double> {
        val a = JSONObject(call("GET", "/api/v3/account", signed = true)).getJSONArray("balances")
        return (0 until a.length()).associate { a.getJSONObject(it).let { b -> b.getString("asset") to b.getString("free").toDouble() } }
    }

    fun filters(sym: String): Filters {
        val s = JSONObject(call("GET", "/api/v3/exchangeInfo", mapOf("symbol" to sym))).getJSONArray("symbols").getJSONObject(0)
        val f = s.getJSONArray("filters"); var step = BigDecimal("0.00001"); var minQty = 0.0; var minN = 5.0
        for (i in 0 until f.length()) {
            val o = f.getJSONObject(i)
            when (o.getString("filterType")) {
                "LOT_SIZE" -> { step = BigDecimal(o.getString("stepSize")); minQty = o.getString("minQty").toDouble() }
                "NOTIONAL", "MIN_NOTIONAL" -> minN = o.getString("minNotional").toDouble()
            }
        }
        return Filters(step, minQty, minN, s.getString("baseAsset"))
    }

    fun market(sym: String, side: String, qty: BigDecimal) = JSONObject(call("POST", "/api/v3/order",
        mapOf("symbol" to sym, "side" to side, "type" to "MARKET", "quantity" to qty.toPlainString()), signed = true))
}
